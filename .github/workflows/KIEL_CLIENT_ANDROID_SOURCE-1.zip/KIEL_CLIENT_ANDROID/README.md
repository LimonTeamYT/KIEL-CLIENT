# KIEL CLIENT — Android source project (V1.2)

A native Android companion app for Minecraft Bedrock, with a black-and-green PvP-style UI. This is a source project, not an APK.

## Included app-side features
- FPS/settings guide and saved preference switches.
- Hold-to-zoom visual preview inside the app (not an in-game camera zoom).
- TNT countdown timer inside the app (10 seconds; not synced to in-game TNT).
- Freecam toggle demo inside the app (does not move the Minecraft camera).
- F1 button to hide/show the app's HUD preview only.
- Drop Item demo button (does not drop Minecraft inventory items).
- Crosshair preview settings: size and color, saved locally in app preferences.
- `.mcpack` file picker and attempt to pass the selected file to an Android handler.
- Launches Minecraft Bedrock if installed.

## Compatibility
The companion app can launch the installed Minecraft app, but does not patch the game or guarantee support for every Bedrock version from 1.26 through 1.26.51. Version-by-version testing is still required. In-game Zoom, Freecam, F1 HUD hiding, inventory drop control, TNT tracking, and in-game crosshair modification are not implemented.

## Build
1. Open `KIEL_CLIENT_ANDROID` in Android Studio.
2. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
3. Choose **Build > Build APK(s)**.
4. If successful, the debug APK should appear at `app/build/outputs/apk/debug/`.

Build requirements: Android Gradle Plugin 8.7.3, Gradle 8.9 or compatible, JDK 17+, Android SDK Platform 35. This environment currently has no `gradle` executable or Android SDK, so an APK has not been built or tested here.
