package com.kiel.client;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_PACK = 4102;
    private static final int BG = Color.rgb(9, 13, 10);
    private static final int PANEL = Color.rgb(18, 25, 20);
    private static final int GREEN = Color.rgb(69, 240, 120);
    private static final int WHITE = Color.rgb(238, 245, 239);
    private static final int MUTED = Color.rgb(157, 174, 161);
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("kiel_settings", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(page);

        TextView eyebrow = text("BEDROCK COMPANION  •  V1.2", 11, GREEN, true);
        eyebrow.setLetterSpacing(0.12f);
        page.addView(eyebrow);
        TextView logo = text("KIEL CLIENT", 32, WHITE, true);
        logo.setPadding(0, dp(7), 0, 0);
        page.addView(logo);
        TextView subtitle = text("PLAY SMART. FIGHT CLEAN.", 12, MUTED, true);
        subtitle.setPadding(0, dp(3), 0, dp(18));
        page.addView(subtitle);

        LinearLayout hero = card();
        hero.setOrientation(LinearLayout.VERTICAL);
        TextView status = text("●  READY TO PLAY", 13, GREEN, true);
        hero.addView(status);
        TextView note = text("Настройки и ресурс-паки для Minecraft Bedrock", 15, WHITE, true);
        note.setPadding(0, dp(9), 0, dp(5));
        hero.addView(note);
        hero.addView(text("Приложение-компаньон: оно не внедряется в игру и не обещает искусственный FPS-буст.", 12, MUTED, false));
        page.addView(hero, marginBottom(16));

        section(page, "01 / PERFORMANCE");
        Switch lowGraphics = makeSwitch("Low Graphics Guide", "Подсказки для более стабильного FPS", "low_graphics");
        page.addView(switchCard(lowGraphics), marginBottom(8));
        Switch particles = makeSwitch("Minimal Particles", "Совет отключить лишние частицы в игре", "particles");
        page.addView(switchCard(particles), marginBottom(8));
        Button guide = button("ОТКРЫТЬ FPS-НАСТРОЙКИ");
        guide.setOnClickListener(v -> showGraphicsGuide());
        page.addView(guide, marginBottom(18));

        section(page, "02 / ZOOM • HOLD TO ACTIVATE");
        LinearLayout zoomCard = card();
        zoomCard.setOrientation(LinearLayout.VERTICAL);
        TextView zoomPreview = text("KIEL", 28, GREEN, true);
        zoomPreview.setGravity(Gravity.CENTER);
        zoomPreview.setPadding(0, dp(8), 0, dp(8));
        zoomCard.addView(zoomPreview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));
        Button zoomHold = button("ЗАЖМИ • ZOOM DEMO");
        zoomHold.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                zoomPreview.animate().scaleX(1.45f).scaleY(1.45f).setDuration(100).start();
                zoomHold.setText("ZOOM ACTIVE • ОТПУСТИ");
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                zoomPreview.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                zoomHold.setText("ЗАЖМИ • ZOOM DEMO");
                view.performClick();
                return true;
            }
            return true;
        });
        zoomHold.setOnClickListener(v -> { /* Accessibility click; touch handling controls the demo. */ });
        zoomCard.addView(zoomHold);
        TextView zoomNote = text("Демо удержания внутри приложения. Эта кнопка пока не меняет камеру Minecraft: для внутриигрового Zoom нужна совместимая интеграция с самой игрой.", 12, MUTED, false);
        zoomNote.setPadding(0, dp(10), 0, 0);
        zoomCard.addView(zoomNote);
        page.addView(zoomCard, marginBottom(18));

        section(page, "03 / PVP TOOLS • DEMO");
        LinearLayout toolsCard = card();
        toolsCard.setOrientation(LinearLayout.VERTICAL);
        toolsCard.addView(text("TNT TIMER", 15, WHITE, true));
        TextView tntStatus = text("Таймер не запущен", 13, MUTED, false);
        tntStatus.setPadding(0, dp(6), 0, dp(9));
        toolsCard.addView(tntStatus);
        Button tntButton = button("ЗАПУСТИТЬ ТАЙМЕР 10 СЕК.");
        tntButton.setOnClickListener(v -> {
            tntButton.setEnabled(false);
            new CountDownTimer(10000, 100) {
                @Override public void onTick(long millisUntilFinished) {
                    tntStatus.setText(String.format(java.util.Locale.US, "Осталось: %.1f сек.", millisUntilFinished / 1000.0));
                }
                @Override public void onFinish() {
                    tntStatus.setText("Таймер завершён • это таймер приложения");
                    tntButton.setEnabled(true);
                }
            }.start();
        });
        toolsCard.addView(tntButton, marginBottom(14));

        toolsCard.addView(text("FREECAM", 15, WHITE, true));
        TextView freecamStatus = text("Выключено • демонстрация", 12, MUTED, false);
        freecamStatus.setPadding(0, dp(5), 0, dp(8));
        toolsCard.addView(freecamStatus);
        Button freecamButton = button("FREECAM: OFF");
        freecamButton.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("freecam_demo", false);
            prefs.edit().putBoolean("freecam_demo", enabled).apply();
            freecamButton.setText(enabled ? "FREECAM: ON (DEMO)" : "FREECAM: OFF");
            freecamStatus.setText(enabled ? "Демо включено в приложении; камера игры не меняется" : "Выключено • демонстрация");
        });
        toolsCard.addView(freecamButton, marginBottom(14));
        freecamButton.setText(prefs.getBoolean("freecam_demo", false) ? "FREECAM: ON (DEMO)" : "FREECAM: OFF");

        toolsCard.addView(text("F1 • HUD", 15, WHITE, true));
        TextView hudPreview = text("KIEL HUD PREVIEW  •  FPS --  •  XYZ --", 12, GREEN, true);
        hudPreview.setPadding(0, dp(8), 0, dp(8));
        toolsCard.addView(hudPreview);
        Button f1Button = button("F1 • СКРЫТЬ HUD PREVIEW");
        f1Button.setOnClickListener(v -> {
            boolean hidden = hudPreview.getVisibility() == View.VISIBLE;
            hudPreview.setVisibility(hidden ? View.GONE : View.VISIBLE);
            f1Button.setText(hidden ? "F1 • ПОКАЗАТЬ HUD PREVIEW" : "F1 • СКРЫТЬ HUD PREVIEW");
        });
        toolsCard.addView(f1Button, marginBottom(14));

        toolsCard.addView(text("DROP ITEM", 15, WHITE, true));
        Button dropButton = button("КНОПКА ВЫБРОСА ПРЕДМЕТА • ДЕМО");
        dropButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Drop Item")
                .setMessage("Кнопка работает только в этом приложении. Она не может выбрасывать предмет из Minecraft Bedrock без внутриигровой интеграции.")
                .setPositiveButton("ПОНЯТНО", null).show());
        toolsCard.addView(dropButton, marginBottom(14));

        toolsCard.addView(text("НАСТРОЙКА ПРИЦЕЛА", 15, WHITE, true));
        TextView crosshairPreview = text("+", 34, GREEN, true);
        crosshairPreview.setGravity(Gravity.CENTER);
        crosshairPreview.setPadding(0, dp(5), 0, dp(5));
        toolsCard.addView(crosshairPreview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(60)));
        Button crosshairButton = button("НАСТРОИТЬ ПРИЦЕЛ");
        crosshairButton.setOnClickListener(v -> showCrosshairSettings(crosshairPreview));
        toolsCard.addView(crosshairButton);
        TextView toolNote = text("TNT Timer, Freecam, F1, Drop Item и прицел здесь демонстрируются внутри KIEL CLIENT. Они пока не управляют Minecraft изнутри. Настоящие внутриигровые функции требуют совместимой интеграции.", 12, MUTED, false);
        toolNote.setPadding(0, dp(12), 0, 0);
        toolsCard.addView(toolNote);
        page.addView(toolsCard, marginBottom(18));

        section(page, "04 / RESOURCE PACKS");
        LinearLayout packCard = card();
        packCard.setOrientation(LinearLayout.VERTICAL);
        packCard.addView(text("Установить PvP-пак", 16, WHITE, true));
        TextView packDesc = text("Выбери .mcpack или .mcaddon в памяти телефона. Дальше Android попробует передать файл Minecraft.", 12, MUTED, false);
        packDesc.setPadding(0, dp(7), 0, dp(12));
        packCard.addView(packDesc);
        Button importButton = button("ИМПОРТИРОВАТЬ .MCPACK");
        importButton.setOnClickListener(v -> pickPack());
        packCard.addView(importButton);
        page.addView(packCard, marginBottom(18));

        section(page, "05 / QUICK LAUNCH");
        Button launch = button("ЗАПУСТИТЬ MINECRAFT");
        launch.setOnClickListener(v -> launchMinecraft());
        page.addView(launch, marginBottom(10));
        Button about = outlineButton("О KIEL CLIENT");
        about.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("KIEL CLIENT")
                .setMessage("Чёрно-зелёный companion app для Minecraft Bedrock. Есть FPS-памятка, передача .mcpack, Zoom preview, TNT timer, Freecam/F1/Drop Item demos и настройка прицела в предпросмотре. Эти элементы не управляют самой игрой. Это не модифицированный клиент и не движок FPS-ускорения.")
                .setPositiveButton("ПОНЯТНО", null).show());
        page.addView(about, marginBottom(18));

        TextView footer = text("KIEL  •  GREEN PVP EDITION  •  V1.2\nMinecraft должен быть установлен отдельно.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(5), 0, 0);
        page.addView(footer);
        setContentView(scroll);
    }

    private void showCrosshairSettings(TextView preview) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), dp(4));
        TextView sample = text("+", 34, GREEN, true);
        sample.setGravity(Gravity.CENTER);
        layout.addView(sample, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));
        TextView sizeLabel = text("Размер прицела", 13, WHITE, true);
        layout.addView(sizeLabel);
        SeekBar size = new SeekBar(this);
        size.setMax(40);
        size.setProgress(prefs.getInt("crosshair_size", 14));
        layout.addView(size);
        String[] colors = {"Зелёный", "Белый", "Красный", "Голубой"};
        int[] colorValues = {GREEN, Color.WHITE, Color.RED, Color.CYAN};
        int selected = prefs.getInt("crosshair_color", 0);
        final int[] currentColor = {Math.max(0, Math.min(3, selected))};
        Button colorButton = outlineButton("ЦВЕТ: " + colors[currentColor[0]].toUpperCase(java.util.Locale.ROOT));
        colorButton.setOnClickListener(v -> {
            currentColor[0] = (currentColor[0] + 1) % colors.length;
            colorButton.setText("ЦВЕТ: " + colors[currentColor[0]].toUpperCase(java.util.Locale.ROOT));
            sample.setTextColor(colorValues[currentColor[0]]);
        });
        sample.setTextColor(colorValues[currentColor[0]]);
        layout.addView(colorButton);
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sample.setTextSize(20 + progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        sample.setTextSize(20 + size.getProgress());
        new AlertDialog.Builder(this).setTitle("Crosshair • Preview")
                .setView(layout)
                .setNegativeButton("ОТМЕНА", null)
                .setPositiveButton("СОХРАНИТЬ", (dialog, which) -> {
                    int progress = size.getProgress();
                    prefs.edit().putInt("crosshair_size", progress).putInt("crosshair_color", currentColor[0]).apply();
                    preview.setTextSize(20 + progress);
                    preview.setTextColor(colorValues[currentColor[0]]);
                    toast("Настройки прицела сохранены для предпросмотра.");
                }).show();
    }

    private void showGraphicsGuide() {
        new AlertDialog.Builder(this)
                .setTitle("FPS GUIDE • BEDROCK")
                .setMessage("Попробуй эти настройки в Minecraft:\n\n• Дальность прорисовки: 4–6 чанков\n• Красивое небо и лишние эффекты: выключить, если есть просадки\n• Частицы: минимально\n• Закрой фоновые приложения\n• Оставь свободное место в памяти и дай телефону остыть\n\nРезультат зависит от телефона, мира и сервера. Приложение не может гарантировать 60/90 FPS или изменить FPS игры напрямую.")
                .setPositiveButton("ОК", null).show();
    }

    private void pickPack() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/octet-stream", "application/x-zip-compressed"});
        try { startActivityForResult(intent, PICK_PACK); }
        catch (ActivityNotFoundException e) { toast("Не найден файловый менеджер."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PACK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(uri, "application/zip");
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(open);
        } catch (ActivityNotFoundException e) {
            new AlertDialog.Builder(this).setTitle("Файл выбран")
                    .setMessage("Android не нашёл приложение для автоматического импорта. Открой .mcpack через приложение «Файлы» и выбери Minecraft, либо импортируй пак из меню Minecraft.")
                    .setPositiveButton("ОК", null).show();
        }
    }

    private void launchMinecraft() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
        if (launch == null) { toast("Minecraft Bedrock не найден. Установи игру отдельно."); return; }
        try { startActivity(launch); }
        catch (ActivityNotFoundException e) { toast("Не получилось запустить Minecraft."); }
    }

    private Switch makeSwitch(String title, String desc, String key) {
        Switch s = new Switch(this);
        s.setText(title + "\n" + desc);
        s.setTextColor(WHITE);
        s.setTextSize(14);
        s.setPadding(0, dp(3), dp(2), dp(3));
        s.setMinHeight(dp(48));
        s.setChecked(prefs.getBoolean(key, false));
        s.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean(key, checked).apply());
        return s;
    }

    private LinearLayout switchCard(Switch s) {
        LinearLayout box = card();
        box.addView(s);
        return box;
    }

    private void section(LinearLayout parent, String title) {
        TextView t = text(title, 11, GREEN, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(dp(2), dp(3), 0, dp(10));
        parent.addView(t);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.rgb(37, 57, 42));
        l.setBackground(bg);
        return l;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.rgb(5, 18, 9));
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(roundRect(GREEN, 13));
        return b;
    }

    private Button outlineButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(GREEN);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(PANEL, 13));
        return b;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (color == PANEL) d.setStroke(dp(1), GREEN);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams marginBottom(int bottom) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT) {{ bottomMargin = dp(bottom); }};
    }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
